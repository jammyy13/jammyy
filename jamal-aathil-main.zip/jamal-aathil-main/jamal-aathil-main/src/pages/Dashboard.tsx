import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/ui/StatCard';
import { useAppData } from '@/contexts/AppDataContext';
import { Users, ScanFace, AlertTriangle, Clock } from 'lucide-react';
import { format } from 'date-fns';

export default function Dashboard() {
  const { criminals, logs, totalRecognitions, alerts } = useAppData();

  const recentLogs = logs.slice(0, 5);

  return (
    <MainLayout>
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>Overview of system activity and statistics</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Criminals"
          value={criminals.length}
          icon={Users}
          description="In database"
          variant="default"
        />
        <StatCard
          title="Total Recognitions"
          value={totalRecognitions}
          icon={ScanFace}
          description="Face scans performed"
          variant="accent"
        />
        <StatCard
          title="Active Alerts"
          value={alerts}
          icon={AlertTriangle}
          description="Matches found"
          variant="warning"
        />
        <StatCard
          title="System Status"
          value="Online"
          icon={Clock}
          description="All systems operational"
          variant="success"
        />
      </div>

      {/* Recent Activity */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Recent Logs */}
        <div className="card-elevated">
          <div className="p-6 border-b border-border">
            <h2 className="font-semibold text-lg">Recent Activity</h2>
          </div>
          <div className="divide-y divide-border">
            {recentLogs.map((log) => (
              <div key={log.id} className="p-4 flex items-center justify-between table-row-hover">
                <div className="flex items-center gap-4">
                  <div className={`w-2 h-2 rounded-full ${
                    log.result === 'Matched' ? 'bg-destructive' : 'bg-success'
                  }`} />
                  <div>
                    <p className="font-medium text-foreground">
                      {log.result === 'Matched' ? `Match: ${log.matchedCriminal}` : 'No Match Found'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {format(log.date, 'MMM dd, yyyy HH:mm')}
                    </p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  log.result === 'Matched' 
                    ? 'bg-destructive/10 text-destructive' 
                    : 'bg-success/10 text-success'
                }`}>
                  {log.accuracy.toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Criminals */}
        <div className="card-elevated">
          <div className="p-6 border-b border-border">
            <h2 className="font-semibold text-lg">Recent Additions</h2>
          </div>
          <div className="divide-y divide-border">
            {criminals.slice(-5).reverse().map((criminal) => (
              <div key={criminal.id} className="p-4 flex items-center gap-4 table-row-hover">
                <img
                  src={criminal.imageUrl}
                  alt={criminal.name}
                  className="w-12 h-12 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <p className="font-medium text-foreground">{criminal.name}</p>
                  <p className="text-sm text-muted-foreground">{criminal.crime}</p>
                </div>
                <span className="text-sm text-muted-foreground">
                  {format(criminal.addedAt, 'MMM dd')}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
