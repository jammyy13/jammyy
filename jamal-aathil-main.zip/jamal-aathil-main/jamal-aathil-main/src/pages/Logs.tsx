import { useState, useEffect, useCallback } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { FileText, AlertTriangle, CheckCircle, Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';

interface LogEntry {
  id: string;
  detected_at: string;
  result: string;
  confidence: number | null;
  matched_criminal_name: string | null;
  camera_name: string | null;
  camera_location: string | null;
  reasoning: string | null;
}

export default function Logs() {
  const { user } = useAuth();
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchLogs = useCallback(async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('surveillance_detections')
        .select('id, detected_at, result, confidence, matched_criminal_name, camera_name, camera_location, reasoning')
        .order('detected_at', { ascending: false })
        .limit(200);

      if (error) throw error;
      setLogs(data || []);
    } catch (err) {
      console.error('Error fetching logs:', err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const matchedCount = logs.filter(l => l.result === 'Matched').length;
  const unknownCount = logs.filter(l => l.result === 'Unknown').length;

  return (
    <MainLayout>
      <div className="page-header flex items-start justify-between">
        <div>
          <h1>Activity Logs</h1>
          <p>Complete history of all face recognition scans</p>
        </div>
        <Button variant="outline" size="sm" onClick={fetchLogs} disabled={isLoading} className="gap-2">
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="card-elevated p-4 text-center">
          <p className="text-2xl font-bold text-foreground">{logs.length}</p>
          <p className="text-sm text-muted-foreground">Total Scans</p>
        </div>
        <div className="card-elevated p-4 text-center">
          <p className="text-2xl font-bold text-destructive">{matchedCount}</p>
          <p className="text-sm text-muted-foreground">Matches Found</p>
        </div>
        <div className="card-elevated p-4 text-center">
          <p className="text-2xl font-bold text-success">{unknownCount}</p>
          <p className="text-sm text-muted-foreground">Unknown Faces</p>
        </div>
      </div>

      {/* Logs Table */}
      <div className="card-elevated overflow-hidden">
        <div className="p-4 border-b border-border flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <h2 className="font-semibold">Recognition History</h2>
        </div>
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-16">Status</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Result</TableHead>
                <TableHead>Matched Criminal</TableHead>
                <TableHead className="text-right">Confidence</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((log) => (
                <TableRow key={log.id} className="table-row-hover">
                  <TableCell>
                    {log.result === 'Matched' ? (
                      <AlertTriangle className="w-5 h-5 text-destructive" />
                    ) : (
                      <CheckCircle className="w-5 h-5 text-success" />
                    )}
                  </TableCell>
                  <TableCell className="font-medium">
                    {format(new Date(log.detected_at), 'MMM dd, yyyy')}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {format(new Date(log.detected_at), 'HH:mm:ss')}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {log.camera_name || '—'}
                  </TableCell>
                  <TableCell>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      log.result === 'Matched'
                        ? 'bg-destructive/10 text-destructive'
                        : 'bg-success/10 text-success'
                    }`}>
                      {log.result}
                    </span>
                  </TableCell>
                  <TableCell>
                    {log.matched_criminal_name || (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    <span className={`font-medium ${
                      (log.confidence ?? 0) >= 90 ? 'text-success' : 
                      (log.confidence ?? 0) >= 85 ? 'text-warning' : 'text-muted-foreground'
                    }`}>
                      {log.confidence?.toFixed(1) ?? '—'}%
                    </span>
                  </TableCell>
                </TableRow>
              ))}
              {logs.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                    No recognition logs yet. Start by scanning a face in the Recognition page.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </div>
    </MainLayout>
  );
}
