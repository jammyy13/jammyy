import { MainLayout } from '@/components/layout/MainLayout';
import { 
  Shield, 
  Scale, 
  Eye, 
  Lock, 
  Users, 
  AlertTriangle,
  BookOpen,
  Target
} from 'lucide-react';

export default function About() {
  return (
    <MainLayout>
      <div className="page-header">
        <h1>About & Ethics</h1>
        <p>Understanding the system and its ethical implications</p>
      </div>

      {/* Creators Section */}
      <section className="card-elevated p-8 mb-8 border border-primary/20">
        <div className="flex items-start gap-4 mb-6">
          <div className="p-3 rounded-xl bg-primary/10">
            <Users className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-semibold mb-2">Created By</h2>
            <p className="text-muted-foreground">BSc Information Technology | Final Year Project</p>
          </div>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="flex items-center gap-4 p-4 rounded-lg bg-muted/50">
            <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-xl font-bold text-primary">J</span>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Jamal</h3>
              <p className="text-sm text-muted-foreground">Developer & Researcher</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-4 rounded-lg bg-muted/50">
            <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-xl font-bold text-primary">A</span>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Aathil</h3>
              <p className="text-sm text-muted-foreground">Developer & Researcher</p>
            </div>
          </div>
        </div>
      </section>

      {/* Project Overview */}
      <section className="card-elevated p-8 mb-8">
        <div className="flex items-start gap-4 mb-6">
          <div className="p-3 rounded-xl bg-primary/10">
            <BookOpen className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-semibold mb-2">Project Overview</h2>
            <p className="text-muted-foreground">AI-Based Face Recognition System</p>
          </div>
        </div>
        <div className="prose prose-gray max-w-none">
          <p className="text-foreground/80 leading-relaxed">
            This AI-Based Face Recognition System for Criminal Identification is a final year project 
            designed by Jamal and Aathil to demonstrate the application of machine learning and computer vision in law 
            enforcement scenarios. The system uses advanced facial recognition algorithms to match 
            uploaded images against a database of known criminals.
          </p>
          <div className="grid md:grid-cols-2 gap-6 mt-6">
            <div className="flex items-start gap-3">
              <Target className="w-5 h-5 text-primary mt-0.5" />
              <div>
                <h4 className="font-medium mb-1">Objective</h4>
                <p className="text-sm text-muted-foreground">
                  To develop a prototype system capable of real-time facial recognition 
                  for criminal identification purposes.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-primary mt-0.5" />
              <div>
                <h4 className="font-medium mb-1">Scope</h4>
                <p className="text-sm text-muted-foreground">
                  Academic demonstration of AI capabilities in security applications, 
                  not intended for production deployment.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Ethical Considerations */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
          <Scale className="w-5 h-5 text-primary" />
          Ethical Considerations
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          <EthicsCard
            icon={Eye}
            title="Privacy Concerns"
            description="Facial recognition technology raises significant privacy issues. This system is designed with strict access controls and should only be used by authorized personnel."
          />
          <EthicsCard
            icon={AlertTriangle}
            title="Bias & Accuracy"
            description="AI systems can exhibit biases based on training data. Results should always be verified by human operators and not used as sole evidence."
          />
          <EthicsCard
            icon={Lock}
            title="Data Security"
            description="Criminal database and recognition logs contain sensitive information. All data must be encrypted and access strictly controlled."
          />
          <EthicsCard
            icon={Users}
            title="Human Oversight"
            description="Technology should assist, not replace, human judgment. All matches must be verified by trained personnel before any action is taken."
          />
        </div>
      </section>

      {/* Technical Details */}
      <section className="card-elevated p-8 mb-8">
        <h2 className="text-xl font-semibold mb-6">Technical Architecture</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <TechCard
            title="Frontend"
            items={['React.js', 'TypeScript', 'Tailwind CSS', 'Shadcn/UI']}
          />
          <TechCard
            title="Recognition Engine"
            items={['Deep Learning CNN', 'Feature Extraction', 'Similarity Matching', 'Real-time Processing']}
          />
          <TechCard
            title="Data Management"
            items={['Secure Storage', 'Encrypted Records', 'Access Logging', 'Audit Trail']}
          />
        </div>
      </section>

      {/* Disclaimer */}
      <section className="bg-warning/10 border border-warning/30 rounded-lg p-6">
        <div className="flex items-start gap-4">
          <AlertTriangle className="w-6 h-6 text-warning flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-warning mb-2">Disclaimer</h3>
            <p className="text-sm text-foreground/70">
              This system is developed for academic and demonstration purposes only. It is not intended 
              for actual law enforcement use. Any resemblance to real persons in the demo data is purely 
              coincidental. The accuracy metrics shown are simulated for demonstration. Real-world 
              deployment of such systems requires extensive testing, validation, legal compliance, 
              and ethical review.
            </p>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}

function EthicsCard({ icon: Icon, title, description }: { 
  icon: React.ComponentType<{ className?: string }>; 
  title: string; 
  description: string;
}) {
  return (
    <div className="card-elevated p-6">
      <div className="flex items-start gap-4">
        <div className="p-2 rounded-lg bg-primary/10">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold mb-2">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
    </div>
  );
}

function TechCard({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="text-center">
      <h3 className="font-semibold mb-3">{title}</h3>
      <ul className="space-y-2">
        {items.map((item, i) => (
          <li key={i} className="text-sm text-muted-foreground">{item}</li>
        ))}
      </ul>
    </div>
  );
}
