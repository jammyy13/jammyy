import { useState, useRef, useCallback } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAppData } from '@/contexts/AppDataContext';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Video, 
  Upload, 
  Play, 
  Pause, 
  AlertTriangle, 
  CheckCircle,
  Camera,
  Clock,
  User,
  Shield,
  Loader2,
  Eye,
  FileVideo,
  Radio
} from 'lucide-react';
import { format } from 'date-fns';
import { SurveillanceDetectionCard } from '@/components/surveillance/SurveillanceDetectionCard';
import { SurveillanceAlerts } from '@/components/surveillance/SurveillanceAlerts';
import { VideoFrameExtractor } from '@/components/surveillance/VideoFrameExtractor';
import { WebcamFeed } from '@/components/surveillance/WebcamFeed';

interface Detection {
  id: string;
  cameraName: string;
  cameraLocation: string;
  detectedAt: Date;
  result: 'matched' | 'unknown' | 'no_face';
  matchedCriminalName?: string;
  matchedCriminalCrime?: string;
  confidence?: number;
  facialFeaturesScore?: number;
  structuralSimilarityScore?: number;
  reasoning?: string;
  frameImageUrl?: string;
  isAlert: boolean;
}

type SourceMode = 'upload' | 'webcam';

export default function Surveillance() {
  const { criminals } = useAppData();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [detections, setDetections] = useState<Detection[]>([]);
  const [activeAlerts, setActiveAlerts] = useState<Detection[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [currentFrame, setCurrentFrame] = useState<string | null>(null);
  const [processedFrames, setProcessedFrames] = useState(0);
  const [cameraName, setCameraName] = useState('Camera 1');
  const [cameraLocation, setCameraLocation] = useState('Main Entrance');
  const [sourceMode, setSourceMode] = useState<SourceMode>('upload');
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setSelectedVideo(file);
      const url = URL.createObjectURL(file);
      setVideoUrl(url);
      setDetections([]);
      setProcessedFrames(0);
      toast({ title: "Video Loaded", description: `${file.name} is ready for analysis` });
    } else {
      toast({ title: "Invalid File", description: "Please upload a valid video file", variant: "destructive" });
    }
  };

  const analyzeFrame = async (frameBase64: string, frameNumber: number): Promise<Detection | null> => {
    try {
      const { data, error } = await supabase.functions.invoke('face-analysis', {
        body: {
          uploadedImage: frameBase64,
          criminals: criminals.map(c => ({
            id: c.id,
            name: c.name,
            crime: c.crime,
            imageUrl: c.imageUrl,
          })),
        },
      });

      if (error) throw error;

      const isMatch = data.matched && data.accuracy >= 70;
      
      return {
        id: `${Date.now()}-${frameNumber}`,
        cameraName,
        cameraLocation,
        detectedAt: new Date(),
        result: data.matched ? 'matched' : 'unknown',
        matchedCriminalName: data.matchedCriminal?.name,
        matchedCriminalCrime: data.matchedCriminal?.crime,
        confidence: data.accuracy,
        facialFeaturesScore: data.analysisDetails?.facialFeaturesScore,
        structuralSimilarityScore: data.analysisDetails?.structuralSimilarityScore,
        reasoning: data.reasoning,
        frameImageUrl: frameBase64,
        isAlert: isMatch,
      };
    } catch (error) {
      console.error('Frame analysis error:', error);
      return null;
    }
  };

  const handleFrameExtracted = useCallback(async (frameBase64: string, frameNumber: number) => {
    setCurrentFrame(frameBase64);
    const detection = await analyzeFrame(frameBase64, frameNumber);
    
    if (detection) {
      setDetections(prev => [detection, ...prev]);
      
      if (detection.isAlert) {
        setActiveAlerts(prev => [detection, ...prev]);
        toast({
          title: "🚨 Criminal Detected!",
          description: `${detection.matchedCriminalName} detected at ${cameraLocation}`,
          variant: "destructive",
        });
      }
    }
    
    setProcessedFrames(prev => prev + 1);
  }, [cameraName, cameraLocation, criminals, toast]);

  const handleWebcamFrame = useCallback(async (frameBase64: string) => {
    setCurrentFrame(frameBase64);
    const frameNumber = Date.now();
    const detection = await analyzeFrame(frameBase64, frameNumber);

    if (detection) {
      setDetections(prev => [detection, ...prev]);

      if (detection.isAlert) {
        setActiveAlerts(prev => [detection, ...prev]);
        toast({
          title: "🚨 Criminal Detected!",
          description: `${detection.matchedCriminalName} detected at ${cameraLocation}`,
          variant: "destructive",
        });
      }
    }

    setProcessedFrames(prev => prev + 1);
  }, [cameraName, cameraLocation, criminals, toast]);

  const handleProcessingComplete = useCallback(() => {
    setIsProcessing(false);
    toast({
      title: "Analysis Complete",
      description: `Processed ${processedFrames} frames. Found ${activeAlerts.length} matches.`,
    });
  }, [processedFrames, activeAlerts.length, toast]);

  const startProcessing = () => {
    if (sourceMode === 'upload' && !selectedVideo) {
      toast({ title: "No Video Selected", description: "Please upload a video file first", variant: "destructive" });
      return;
    }

    if (criminals.length === 0) {
      toast({ title: "No Criminal Database", description: "Add criminals to the database before running surveillance", variant: "destructive" });
      return;
    }

    setIsProcessing(true);
    setDetections([]);
    setActiveAlerts([]);
    setProcessedFrames(0);
  };

  const stopProcessing = () => {
    setIsProcessing(false);
  };

  return (
    <MainLayout>
      <div className="page-header">
        <div className="flex items-center gap-3">
          <Video className="w-8 h-8 text-primary" />
          <div>
            <h1>CCTV Surveillance</h1>
            <p>Live criminal detection and real-time monitoring</p>
          </div>
        </div>
      </div>

      {/* Security Notice */}
      <Card className="mb-6 border-primary/30 bg-primary/5">
        <CardContent className="p-4 flex items-start gap-3">
          <Shield className="w-5 h-5 text-primary mt-0.5" />
          <div className="text-sm">
            <p className="font-medium text-foreground">Secure Surveillance System</p>
            <p className="text-muted-foreground">
              All detections are encrypted and logged securely. Access is restricted to authorized personnel only.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card className="card-elevated">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
              <Camera className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">{processedFrames}</p>
              <p className="text-sm text-muted-foreground">Frames Analyzed</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="card-elevated">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
              <Eye className="w-6 h-6 text-muted-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold">{detections.filter(d => d.result === 'unknown').length}</p>
              <p className="text-sm text-muted-foreground">Unknown Faces</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="card-elevated">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-destructive" />
            </div>
            <div>
              <p className="text-2xl font-bold text-destructive">{activeAlerts.length}</p>
              <p className="text-sm text-muted-foreground">Active Alerts</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="card-elevated">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
              <User className="w-6 h-6 text-accent-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold">{criminals.length}</p>
              <p className="text-sm text-muted-foreground">Criminals in DB</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Video Source Panel */}
        <div className="lg:col-span-2 space-y-6">
          {/* Camera Settings */}
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="w-5 h-5" />
                Camera Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Camera Name</label>
                  <input
                    type="text"
                    value={cameraName}
                    onChange={(e) => setCameraName(e.target.value)}
                    className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground"
                    placeholder="e.g., Camera 1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Location</label>
                  <input
                    type="text"
                    value={cameraLocation}
                    onChange={(e) => setCameraLocation(e.target.value)}
                    className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground"
                    placeholder="e.g., Main Entrance"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Source Mode Toggle */}
          <div className="flex gap-2">
            <Button
              variant={sourceMode === 'upload' ? 'default' : 'outline'}
              onClick={() => { setSourceMode('upload'); setIsProcessing(false); }}
              className="flex-1"
            >
              <FileVideo className="w-4 h-4 mr-2" />
              Upload Video
            </Button>
            <Button
              variant={sourceMode === 'webcam' ? 'default' : 'outline'}
              onClick={() => { setSourceMode('webcam'); setIsProcessing(false); }}
              className="flex-1"
            >
              <Radio className="w-4 h-4 mr-2" />
              Live Webcam
            </Button>
          </div>

          {/* Upload Mode */}
          {sourceMode === 'upload' && (
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileVideo className="w-5 h-5" />
                  Video Source
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <label className="block cursor-pointer">
                    <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors">
                      <Upload className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                      <p className="text-lg font-medium">Upload CCTV Footage</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Supports MP4, WebM, AVI formats
                      </p>
                      <input
                        type="file"
                        accept="video/*"
                        onChange={handleVideoUpload}
                        className="hidden"
                        disabled={isProcessing}
                      />
                    </div>
                  </label>

                  {videoUrl && (
                    <div className="space-y-4">
                      <div className="relative rounded-lg overflow-hidden bg-black">
                        <video
                          ref={videoRef}
                          src={videoUrl}
                          controls
                          className="w-full max-h-[400px]"
                        />
                        {isProcessing && (
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                            <div className="text-center text-white">
                              <Loader2 className="w-12 h-12 animate-spin mx-auto mb-2" />
                              <p className="font-medium">Analyzing Frames...</p>
                              <p className="text-sm opacity-75">
                                {processedFrames} frames processed
                              </p>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-4">
                        {!isProcessing ? (
                          <Button onClick={startProcessing} className="flex-1" size="lg">
                            <Play className="w-5 h-5 mr-2" />
                            Start Analysis
                          </Button>
                        ) : (
                          <Button onClick={stopProcessing} variant="destructive" className="flex-1" size="lg">
                            <Pause className="w-5 h-5 mr-2" />
                            Stop Analysis
                          </Button>
                        )}
                      </div>

                      {isProcessing && (
                        <div className="p-4 rounded-lg bg-muted/50">
                          <div className="flex justify-between text-sm mb-2">
                            <span>Processing Progress</span>
                            <span className="font-mono">{processedFrames} frames</span>
                          </div>
                          <div className="h-2 rounded-full bg-muted overflow-hidden">
                            <div 
                              className="h-full bg-primary transition-all" 
                              style={{ width: `${Math.min((processedFrames / 10) * 100, 100)}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Webcam Mode */}
          {sourceMode === 'webcam' && (
            <div className="space-y-4">
              <WebcamFeed
                onFrameCaptured={handleWebcamFrame}
                isProcessing={isProcessing}
                captureInterval={5000}
              />
              <div className="flex gap-4">
                {!isProcessing ? (
                  <Button onClick={startProcessing} className="flex-1" size="lg">
                    <Play className="w-5 h-5 mr-2" />
                    Start Live Analysis
                  </Button>
                ) : (
                  <Button onClick={stopProcessing} variant="destructive" className="flex-1" size="lg">
                    <Pause className="w-5 h-5 mr-2" />
                    Stop Analysis
                  </Button>
                )}
              </div>
            </div>
          )}

          {/* Frame Extractor (Hidden but functional) - only for upload mode */}
          {isProcessing && sourceMode === 'upload' && videoRef.current && (
            <VideoFrameExtractor
              video={videoRef.current}
              isProcessing={isProcessing}
              frameInterval={5000}
              onFrameExtracted={handleFrameExtracted}
              onComplete={handleProcessingComplete}
            />
          )}

          {/* Current Frame Being Analyzed */}
          {currentFrame && isProcessing && (
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  Current Frame Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <img 
                  src={currentFrame} 
                  alt="Current frame" 
                  className="w-full rounded-lg"
                />
              </CardContent>
            </Card>
          )}
        </div>

        {/* Alerts & Detection Sidebar */}
        <div className="space-y-6">
          <SurveillanceAlerts alerts={activeAlerts} />

          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Recent Detections
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 max-h-[500px] overflow-y-auto">
              {detections.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No detections yet. Start analysis to begin.
                </p>
              ) : (
                detections.slice(0, 10).map((detection) => (
                  <SurveillanceDetectionCard key={detection.id} detection={detection} />
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Detection History Table */}
      {detections.length > 0 && (
        <Card className="card-elevated mt-8">
          <CardHeader>
            <CardTitle>Detection History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left p-3 text-muted-foreground font-medium">Status</th>
                    <th className="text-left p-3 text-muted-foreground font-medium">Time</th>
                    <th className="text-left p-3 text-muted-foreground font-medium">Camera</th>
                    <th className="text-left p-3 text-muted-foreground font-medium">Location</th>
                    <th className="text-left p-3 text-muted-foreground font-medium">Result</th>
                    <th className="text-left p-3 text-muted-foreground font-medium">Confidence</th>
                  </tr>
                </thead>
                <tbody>
                  {detections.map((detection) => (
                    <tr key={detection.id} className="border-b border-border/50 hover:bg-muted/30">
                      <td className="p-3">
                        {detection.result === 'matched' ? (
                          <AlertTriangle className="w-5 h-5 text-destructive" />
                        ) : (
                          <CheckCircle className="w-5 h-5 text-muted-foreground" />
                        )}
                      </td>
                      <td className="p-3 text-sm">
                        {format(detection.detectedAt, 'HH:mm:ss')}
                      </td>
                      <td className="p-3">{detection.cameraName}</td>
                      <td className="p-3 text-muted-foreground">{detection.cameraLocation}</td>
                      <td className="p-3">
                        {detection.result === 'matched' ? (
                          <span className="text-destructive font-medium">
                            {detection.matchedCriminalName}
                          </span>
                        ) : (
                          <span className="text-muted-foreground">No Match</span>
                        )}
                      </td>
                      <td className="p-3">
                        {detection.confidence && (
                          <Badge variant={detection.confidence >= 80 ? "destructive" : "secondary"}>
                            {detection.confidence.toFixed(1)}%
                          </Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </MainLayout>
  );
}
