import { Link } from 'react-router-dom';
import { Shield, ScanFace, Database, Lock, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
export default function Home() {
  return <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        <div className="relative max-w-7xl mx-auto px-6 py-8">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="font-bold text-xl">FaceID System</span>
            </div>
            <Link to="/login">
              <Button variant="outline" className="gap-2">
                Admin Login
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Hero */}
      <section className="relative py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Shield className="w-4 h-4" />
              BSc IT Final Year Project
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
              AI-Based Face Recognition
              <span className="gradient-text block mt-2">Criminal Identification System</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
              An advanced facial recognition system designed for law enforcement agencies to identify 
              and track criminal suspects using state-of-the-art AI technology.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/login">
                <Button className="btn-gradient text-lg px-8 py-6">
                  Access Admin Panel
                </Button>
              </Link>
              <Link to="/about">
                <Button variant="outline" className="text-lg px-8 py-6">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">System Capabilities</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard icon={ScanFace} title="Real-time Recognition" description="Advanced deep learning algorithms for instant face matching against the criminal database." />
            <FeatureCard icon={Database} title="Criminal Database" description="Secure storage and management of criminal records with comprehensive search capabilities." />
            <FeatureCard icon={Lock} title="Secure Access" description="Role-based authentication ensuring only authorized personnel can access the system." />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-border">
        <div className="max-w-7xl mx-auto text-center text-muted-foreground">
          <p>JAMAL & AATHIL | AI Face Recognition System | BSc IT Final Year Project</p>
          <p className="mt-2 text-sm">Developed for Academic Demonstration Purposes</p>
        </div>
      </footer>
    </div>;
}
function FeatureCard({
  icon: Icon,
  title,
  description
}: {
  icon: React.ComponentType<{
    className?: string;
  }>;
  title: string;
  description: string;
}) {
  return <div className="card-elevated p-6 text-center animate-fade-in">
      <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
        <Icon className="w-7 h-7 text-primary" />
      </div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>;
}