import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { useAppData, Criminal } from '@/contexts/AppDataContext';
import { ImageUpload } from '@/components/ui/ImageUpload';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  ScanFace, AlertTriangle, CheckCircle, Loader2, Brain, 
  Shield, UserX, Users, ExternalLink, ToggleLeft
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface AnalysisResult {
  status: 'analyzed' | 'no_face' | 'multiple_faces';
  matched: boolean;
  accuracy: number;
  matchedCriminal?: Criminal;
  faceCount?: number;
  analysisDetails: {
    facialFeaturesScore: number;
    structuralSimilarityScore: number;
    overallConfidence: number;
  };
  reasoning: string;
}

function generateDemoResult(criminals: Criminal[]): AnalysisResult {
  const shouldMatch = Math.random() > 0.4 && criminals.length > 0;
  const randomCriminal = criminals[Math.floor(Math.random() * criminals.length)];
  const accuracy = shouldMatch ? 75 + Math.random() * 20 : 30 + Math.random() * 30;
  const facialScore = accuracy + (Math.random() * 10 - 5);
  const structuralScore = accuracy + (Math.random() * 10 - 5);

  return {
    status: 'analyzed',
    matched: shouldMatch,
    accuracy: Math.round(accuracy * 10) / 10,
    matchedCriminal: shouldMatch ? randomCriminal : undefined,
    analysisDetails: {
      facialFeaturesScore: Math.round(Math.min(100, Math.max(0, facialScore)) * 10) / 10,
      structuralSimilarityScore: Math.round(Math.min(100, Math.max(0, structuralScore)) * 10) / 10,
      overallConfidence: Math.round(accuracy * 10) / 10,
    },
    reasoning: shouldMatch
      ? `[DEMO] Simulated match found with ${randomCriminal.name}. Facial features show strong similarity in bone structure and proportions.`
      : `[DEMO] No match found. The uploaded face does not correspond to any criminal in the database with sufficient confidence.`,
  };
}

export default function Recognition() {
  const { criminals, addLog } = useAppData();
  const { user } = useAuth();
  const { toast } = useToast();
  const [uploadedImage, setUploadedImage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [demoMode, setDemoMode] = useState(false);

  const handleRecognize = async () => {
    if (!uploadedImage) return;

    setIsProcessing(true);
    setResult(null);

    try {
      let analysisResult: AnalysisResult;

      if (demoMode) {
        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        analysisResult = generateDemoResult(criminals);
      } else {
        const { data, error } = await supabase.functions.invoke('face-analysis', {
          body: {
            uploadedImage,
            criminals: criminals.map(c => ({
              id: c.id,
              name: c.name,
              crime: c.crime,
              imageUrl: c.imageUrl,
            })),
          },
        });

        if (error) {
          toast({ title: "Analysis Failed", description: error.message || "Failed to analyze the image.", variant: "destructive" });
          setIsProcessing(false);
          return;
        }

        if (data.error) {
          toast({ title: "Analysis Error", description: data.error, variant: "destructive" });
          setIsProcessing(false);
          return;
        }

        analysisResult = data as AnalysisResult;
      }

      setResult(analysisResult);

      // Persist log to database
      if (user && analysisResult.status === 'analyzed') {
        await supabase.from('surveillance_detections').insert({
          user_id: user.id,
          result: analysisResult.matched ? 'Matched' : 'Unknown',
          confidence: analysisResult.accuracy,
          matched_criminal_name: analysisResult.matchedCriminal?.name || null,
          matched_criminal_id: analysisResult.matchedCriminal?.id || null,
          matched_criminal_crime: analysisResult.matchedCriminal?.crime || null,
          facial_features_score: analysisResult.analysisDetails?.facialFeaturesScore || null,
          structural_similarity_score: analysisResult.analysisDetails?.structuralSimilarityScore || null,
          reasoning: analysisResult.reasoning || null,
          camera_name: 'Manual Upload',
          camera_location: 'Recognition Page',
          is_alert: analysisResult.matched,
        });
      }

      // Also update in-memory logs for dashboard
      addLog({
        date: new Date(),
        result: analysisResult.matched ? 'Matched' : 'Unknown',
        accuracy: analysisResult.accuracy,
        matchedCriminal: analysisResult.matchedCriminal?.name,
      });

      toast({
        title: analysisResult.status === 'no_face' ? "No Face Detected"
          : analysisResult.status === 'multiple_faces' ? "Multiple Faces Detected"
          : analysisResult.matched ? "Match Found!" : "Analysis Complete",
        description: analysisResult.status === 'no_face' ? "Please upload an image containing a clear face."
          : analysisResult.status === 'multiple_faces' ? "Please upload an image with only one face."
          : analysisResult.matched 
            ? `Potential match: ${analysisResult.matchedCriminal?.name}`
            : "No matches found in the criminal database.",
        variant: analysisResult.matched ? "destructive" : "default",
      });

    } catch (err) {
      console.error('Recognition error:', err);
      toast({ title: "Error", description: "An unexpected error occurred during analysis.", variant: "destructive" });
    }

    setIsProcessing(false);
  };

  const resetRecognition = () => {
    setUploadedImage('');
    setResult(null);
  };

  return (
    <MainLayout>
      <div className="page-header">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="flex items-center gap-2">
              <Shield className="w-7 h-7 text-primary" />
              Face Recognition
            </h1>
            <p>Upload an image to identify potential criminal matches</p>
          </div>
          <div className="flex items-center gap-3 px-4 py-2 rounded-lg border border-border bg-card">
            <Label htmlFor="demo-mode" className="text-sm font-medium cursor-pointer flex items-center gap-2">
              <ToggleLeft className="w-4 h-4" />
              Demo Mode
            </Label>
            <Switch id="demo-mode" checked={demoMode} onCheckedChange={setDemoMode} />
            {demoMode && <Badge variant="secondary" className="text-xs">Active</Badge>}
          </div>
        </div>
      </div>

      {demoMode && (
        <Card className="mb-6 border-warning/30 bg-warning/5">
          <CardContent className="p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-warning mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-foreground">Demo Mode Active</p>
              <p className="text-muted-foreground">
                Results are simulated. Disable demo mode to use real AI-powered face recognition.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <div className="card-elevated p-6">
          <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <ScanFace className="w-5 h-5 text-primary" />
            Upload Face Image
          </h2>
          
          <ImageUpload
            onImageSelect={setUploadedImage}
            currentImage={uploadedImage}
            className="mb-6"
          />

          <div className="flex gap-4">
            <Button
              onClick={handleRecognize}
              disabled={!uploadedImage || isProcessing}
              className="btn-gradient flex-1 gap-2"
            >
              {isProcessing ? (
                <><Loader2 className="w-4 h-4 animate-spin" />Processing...</>
              ) : (
                <><ScanFace className="w-4 h-4" />Recognize Face</>
              )}
            </Button>
            {(uploadedImage || result) && (
              <Button variant="outline" onClick={resetRecognition}>Reset</Button>
            )}
          </div>

          {/* Backend Integration Info */}
          <div className="mt-4 p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
            <p className="font-medium mb-1">Backend Integration</p>
            <p>Image → <code className="bg-muted px-1 rounded">/api/recognize</code> (face-analysis) → AI comparison against criminal DB → Match result</p>
          </div>
        </div>

        {/* Results Section */}
        <div className="card-elevated p-6">
          <h2 className="font-semibold text-lg mb-4">Recognition Result</h2>
          
          {!result && !isProcessing && (
            <div className="h-64 flex items-center justify-center text-muted-foreground text-center">
              <div>
                <ScanFace className="w-16 h-16 mx-auto mb-4 opacity-30" />
                <p>Upload an image and click "Recognize Face" to begin analysis</p>
              </div>
            </div>
          )}

          {isProcessing && (
            <div className="h-64 flex items-center justify-center">
              <div className="text-center">
                <div className="relative w-20 h-20 mx-auto mb-4">
                  <div className="absolute inset-0 border-4 border-primary/20 rounded-full" />
                  <div className="absolute inset-0 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
                <p className="text-muted-foreground">
                  {demoMode ? 'Simulating analysis...' : 'Analyzing facial features...'}
                </p>
                <p className="text-sm text-muted-foreground/70 mt-1">This may take a moment</p>
              </div>
            </div>
          )}

          {result && (
            <div className="animate-fade-in space-y-6">
              {/* No Face Detected */}
              {result.status === 'no_face' && (
                <div className="recognition-result flex items-center gap-4 bg-warning/10 border-2 border-warning text-warning-foreground p-4 rounded-lg">
                  <UserX className="w-8 h-8 text-warning" />
                  <div>
                    <p className="text-lg font-semibold">NO FACE DETECTED</p>
                    <p className="text-sm opacity-80">Please upload a clear image containing a human face.</p>
                  </div>
                </div>
              )}

              {/* Multiple Faces */}
              {result.status === 'multiple_faces' && (
                <div className="recognition-result flex items-center gap-4 bg-warning/10 border-2 border-warning text-warning-foreground p-4 rounded-lg">
                  <Users className="w-8 h-8 text-warning" />
                  <div>
                    <p className="text-lg font-semibold">MULTIPLE FACES DETECTED</p>
                    <p className="text-sm opacity-80">
                      {result.faceCount ? `${result.faceCount} faces found. ` : ''}
                      Please upload an image with a single face only.
                    </p>
                  </div>
                </div>
              )}

              {/* Match / No Match Result */}
              {result.status === 'analyzed' && (
                <>
                  <div className={`recognition-result flex items-center gap-4 ${
                    result.matched ? 'matched' : 'unknown'
                  }`}>
                    {result.matched ? (
                      <AlertTriangle className="w-8 h-8" />
                    ) : (
                      <CheckCircle className="w-8 h-8" />
                    )}
                    <div>
                      <p className="text-lg font-semibold">
                        {result.matched ? '🚨 MATCH FOUND' : 'NO MATCH'}
                      </p>
                      <p className="text-sm opacity-80">
                        Confidence: {result.accuracy.toFixed(1)}%
                      </p>
                    </div>
                  </div>

                  {/* Match Result Card */}
                  {result.matched && result.matchedCriminal && (
                    <Card className="border-destructive/30 bg-destructive/5">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Shield className="w-4 h-4 text-destructive" />
                          Matched Criminal Profile
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-start gap-4">
                          <div className="relative flex-shrink-0">
                            <img
                              src={result.matchedCriminal.imageUrl}
                              alt={result.matchedCriminal.name}
                              className="w-24 h-24 rounded-lg object-cover border-2 border-destructive/30"
                            />
                            <div className="bounding-box inset-0" />
                          </div>
                          <div className="flex-1 space-y-2">
                            <p className="font-bold text-xl text-foreground">{result.matchedCriminal.name}</p>
                            <Badge variant="destructive">{result.matchedCriminal.crime}</Badge>
                            <p className="text-sm text-muted-foreground">
                              ID: <span className="font-mono">#{result.matchedCriminal.id.slice(-8)}</span>
                            </p>
                            <p className="text-sm text-muted-foreground flex items-center gap-1">
                              <ExternalLink className="w-3 h-3" />
                              Stored Photo Available
                            </p>
                            <div className="pt-2">
                              <Badge variant="outline" className="text-destructive border-destructive/30">
                                {result.accuracy.toFixed(1)}% Confidence
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Unknown - Best Candidate */}
                  {!result.matched && (
                    <Card className="border-success/30 bg-success/5">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-success" />
                          Result: Unknown Person
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          No criminal in the database matched with sufficient confidence.
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                          Best candidate confidence: <span className="font-mono font-medium">{result.accuracy.toFixed(1)}%</span>
                          <span className="ml-1">(threshold: 70%)</span>
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </>
              )}

              {/* Uploaded Image Preview */}
              {uploadedImage && (
                <div className="border border-border rounded-lg p-4">
                  <p className="text-sm text-muted-foreground mb-3">Analyzed Image:</p>
                  <div className="relative inline-block">
                    <img src={uploadedImage} alt="Uploaded" className="max-h-48 rounded-lg" />
                    {result.matched && (
                      <div className="bounding-box" style={{ top: '15%', left: '20%', width: '60%', height: '70%' }} />
                    )}
                  </div>
                </div>
              )}

              {/* AI Analysis Details */}
              {result.status === 'analyzed' && (
                <div className="border border-border rounded-lg p-4">
                  <p className="text-sm text-muted-foreground mb-3 flex items-center gap-2">
                    <Brain className="w-4 h-4" />
                    AI Analysis Details:
                  </p>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Facial Features Match</span>
                        <span className="font-medium">{result.analysisDetails?.facialFeaturesScore?.toFixed(1) || '0'}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-muted overflow-hidden">
                        <div className="h-full bg-primary transition-all" style={{ width: `${result.analysisDetails?.facialFeaturesScore || 0}%` }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Structural Similarity</span>
                        <span className="font-medium">{result.analysisDetails?.structuralSimilarityScore?.toFixed(1) || '0'}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-muted overflow-hidden">
                        <div className="h-full bg-accent transition-all" style={{ width: `${result.analysisDetails?.structuralSimilarityScore || 0}%` }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Overall Confidence</span>
                        <span className="font-semibold text-primary">{result.accuracy.toFixed(1)}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-muted overflow-hidden">
                        <div className="h-full bg-primary transition-all" style={{ width: `${result.accuracy}%` }} />
                      </div>
                    </div>
                  </div>
                  {result.reasoning && (
                    <div className="mt-4 pt-3 border-t border-border">
                      <p className="text-sm text-muted-foreground mb-1">AI Reasoning:</p>
                      <p className="text-sm">{result.reasoning}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Reasoning for no_face / multiple_faces */}
              {(result.status === 'no_face' || result.status === 'multiple_faces') && result.reasoning && (
                <div className="border border-border rounded-lg p-4">
                  <p className="text-sm text-muted-foreground mb-1">Details:</p>
                  <p className="text-sm">{result.reasoning}</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
