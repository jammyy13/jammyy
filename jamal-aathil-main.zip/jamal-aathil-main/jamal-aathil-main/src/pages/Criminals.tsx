import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { useAppData } from '@/contexts/AppDataContext';
import { ImageUpload } from '@/components/ui/ImageUpload';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Plus, Search, UserPlus, Pencil, Trash2, Loader2, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import type { Criminal } from '@/contexts/AppDataContext';

async function validateFaceInImage(imageData: string): Promise<{ valid: boolean; reason: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('validate-face', {
      body: { image: imageData },
    });

    if (error) return { valid: false, reason: 'Face validation service unavailable. Please try again.' };
    if (data.error) return { valid: false, reason: data.error };

    if (!data.hasFace) {
      return { valid: false, reason: data.reason || 'No clear face detected in the image.' };
    }
    if (data.faceCount > 1) {
      return { valid: false, reason: `Multiple faces (${data.faceCount}) detected. Please upload an image with a single face.` };
    }
    return { valid: true, reason: '' };
  } catch {
    return { valid: false, reason: 'Could not validate image. Please try again.' };
  }
}

export default function Criminals() {
  const { criminals, addCriminal, updateCriminal, deleteCriminal, isLoadingCriminals } = useAppData();
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [imageError, setImageError] = useState('');
  
  // Add form state
  const [name, setName] = useState('');
  const [crime, setCrime] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  // Edit state
  const [editingCriminal, setEditingCriminal] = useState<Criminal | null>(null);
  const [editName, setEditName] = useState('');
  const [editCrime, setEditCrime] = useState('');
  const [editImageUrl, setEditImageUrl] = useState('');
  const [editImageError, setEditImageError] = useState('');

  // Delete confirmation state
  const [deletingCriminal, setDeletingCriminal] = useState<Criminal | null>(null);

  const handleImageSelect = async (image: string) => {
    setImageUrl(image);
    setImageError('');
    if (!image) return;

    setIsValidating(true);
    const result = await validateFaceInImage(image);
    setIsValidating(false);

    if (!result.valid) {
      setImageError(result.reason);
      setImageUrl('');
      toast({ title: "Invalid Image", description: result.reason, variant: "destructive" });
    }
  };

  const handleEditImageSelect = async (image: string) => {
    setEditImageUrl(image);
    setEditImageError('');
    if (!image) return;

    setIsValidating(true);
    const result = await validateFaceInImage(image);
    setIsValidating(false);

    if (!result.valid) {
      setEditImageError(result.reason);
      setEditImageUrl(editingCriminal?.imageUrl || '');
      toast({ title: "Invalid Image", description: result.reason, variant: "destructive" });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !crime || !imageUrl) return;

    setIsSaving(true);
    try {
      await addCriminal({ name, crime, imageUrl });
      setName('');
      setCrime('');
      setImageUrl('');
      setImageError('');
      setShowForm(false);
      toast({ title: "Criminal Added", description: `${name} has been added to the database.` });
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to add criminal.", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const openEdit = (criminal: Criminal) => {
    setEditingCriminal(criminal);
    setEditName(criminal.name);
    setEditCrime(criminal.crime);
    setEditImageUrl(criminal.imageUrl);
    setEditImageError('');
  };

  const handleEditSave = async () => {
    if (!editingCriminal || !editName || !editCrime || !editImageUrl) return;

    setIsSaving(true);
    try {
      await updateCriminal(editingCriminal.id, {
        name: editName,
        crime: editCrime,
        imageUrl: editImageUrl,
      });
      toast({ title: "Record Updated", description: `${editName}'s record has been updated.` });
      setEditingCriminal(null);
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to update record.", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingCriminal) return;

    setIsSaving(true);
    try {
      await deleteCriminal(deletingCriminal.id);
      toast({ title: "Record Deleted", description: `${deletingCriminal.name} has been removed.`, variant: "destructive" });
      setDeletingCriminal(null);
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to delete record.", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const filteredCriminals = criminals.filter(
    c => c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
         c.crime.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <MainLayout>
      <div className="page-header flex items-start justify-between">
        <div>
          <h1>Criminal Database</h1>
          <p>Manage and view criminal records</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="btn-gradient gap-2">
          <Plus className="w-4 h-4" />
          Add Criminal
        </Button>
      </div>

      {/* Add Criminal Form */}
      {showForm && (
        <div className="card-elevated p-6 mb-8 animate-fade-in">
          <h2 className="font-semibold text-lg mb-6 flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-primary" />
            Add New Criminal Record
          </h2>
          <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  placeholder="Enter criminal's full name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="crime">Crime Type</Label>
                <Input
                  id="crime"
                  placeholder="e.g., Robbery, Fraud, Assault"
                  value={crime}
                  onChange={(e) => setCrime(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Photo <span className="text-destructive">*</span> (must contain a face)</Label>
              <ImageUpload
                onImageSelect={handleImageSelect}
                currentImage={imageUrl}
              />
              {isValidating && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" /> Validating face...
                </div>
              )}
              {imageError && (
                <div className="flex items-center gap-2 text-sm text-destructive">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" /> {imageError}
                </div>
              )}
            </div>
            <div className="md:col-span-2 flex gap-4">
              <Button type="submit" className="btn-gradient" disabled={!name || !crime || !imageUrl || isSaving || isValidating}>
                {isSaving ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Saving...</> : 'Add Criminal'}
              </Button>
              <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Search by name or crime..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Criminals Table */}
      <div className="card-elevated overflow-hidden">
        {isLoadingCriminals ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-16">Photo</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Crime</TableHead>
                <TableHead>Date Added</TableHead>
                <TableHead>ID</TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCriminals.map((criminal) => (
                <TableRow key={criminal.id} className="table-row-hover">
                  <TableCell>
                    <img
                      src={criminal.imageUrl}
                      alt={criminal.name}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                  </TableCell>
                  <TableCell className="font-medium">{criminal.name}</TableCell>
                  <TableCell>
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-destructive/10 text-destructive">
                      {criminal.crime}
                    </span>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {format(criminal.addedAt, 'MMM dd, yyyy')}
                  </TableCell>
                  <TableCell className="font-mono text-sm text-muted-foreground">
                    #{criminal.id.slice(-6)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => openEdit(criminal)} className="h-8 w-8">
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setDeletingCriminal(criminal)} className="h-8 w-8 text-destructive hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filteredCriminals.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    {criminals.length === 0 ? 'No criminals in database yet. Add one to get started.' : 'No criminals found matching your search.'}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingCriminal} onOpenChange={(open) => !open && setEditingCriminal(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-5 h-5 text-primary" />
              Edit Criminal Record
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Full Name</Label>
              <Input id="edit-name" value={editName} onChange={(e) => setEditName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-crime">Crime Type</Label>
              <Input id="edit-crime" value={editCrime} onChange={(e) => setEditCrime(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Photo (must contain a face)</Label>
              <ImageUpload onImageSelect={handleEditImageSelect} currentImage={editImageUrl} />
              {isValidating && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" /> Validating face...
                </div>
              )}
              {editImageError && (
                <div className="flex items-center gap-2 text-sm text-destructive">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" /> {editImageError}
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingCriminal(null)}>Cancel</Button>
            <Button onClick={handleEditSave} disabled={!editName || !editCrime || !editImageUrl || isSaving || isValidating}>
              {isSaving ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Saving...</> : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingCriminal} onOpenChange={(open) => !open && setDeletingCriminal(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Criminal Record</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the record for <strong>{deletingCriminal?.name}</strong>? 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90" disabled={isSaving}>
              {isSaving ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
