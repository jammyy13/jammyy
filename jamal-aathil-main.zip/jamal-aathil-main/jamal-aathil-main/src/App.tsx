import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { AppDataProvider } from "@/contexts/AppDataContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Criminals from "./pages/Criminals";
import Recognition from "./pages/Recognition";
import Surveillance from "./pages/Surveillance";
import Logs from "./pages/Logs";
import About from "./pages/About";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <AppDataProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/dashboard" element={
                <ProtectedRoute><Dashboard /></ProtectedRoute>
              } />
              <Route path="/criminals" element={
                <ProtectedRoute><Criminals /></ProtectedRoute>
              } />
              <Route path="/recognition" element={
                <ProtectedRoute><Recognition /></ProtectedRoute>
              } />
              <Route path="/surveillance" element={
                <ProtectedRoute><Surveillance /></ProtectedRoute>
              } />
              <Route path="/logs" element={
                <ProtectedRoute><Logs /></ProtectedRoute>
              } />
              <Route path="/about" element={
                <ProtectedRoute><About /></ProtectedRoute>
              } />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AppDataProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
