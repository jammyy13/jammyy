import { Bell, AlertTriangle, MapPin, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

interface Detection {
  id: string;
  cameraName: string;
  cameraLocation: string;
  detectedAt: Date;
  result: 'matched' | 'unknown' | 'no_face';
  matchedCriminalName?: string;
  matchedCriminalCrime?: string;
  confidence?: number;
  isAlert: boolean;
}

interface SurveillanceAlertsProps {
  alerts: Detection[];
}

export function SurveillanceAlerts({ alerts }: SurveillanceAlertsProps) {
  return (
    <Card className="card-elevated border-destructive/30">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-destructive">
          <Bell className="w-5 h-5" />
          Active Alerts
          {alerts.length > 0 && (
            <Badge variant="destructive" className="ml-auto">
              {alerts.length}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {alerts.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <AlertTriangle className="w-12 h-12 mx-auto mb-2 opacity-30" />
            <p>No active alerts</p>
            <p className="text-sm">Alerts will appear when criminals are detected</p>
          </div>
        ) : (
          alerts.slice(0, 5).map((alert) => (
            <div 
              key={alert.id} 
              className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 animate-pulse"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-destructive/20">
                  <AlertTriangle className="w-4 h-4 text-destructive" />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-destructive">
                    {alert.matchedCriminalName}
                  </p>
                  <p className="text-sm text-destructive/80">
                    {alert.matchedCriminalCrime}
                  </p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {format(alert.detectedAt, 'HH:mm:ss')}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {alert.cameraLocation}
                    </span>
                  </div>
                  {alert.confidence && (
                    <Badge variant="destructive" className="mt-2">
                      {alert.confidence.toFixed(1)}% Match
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
