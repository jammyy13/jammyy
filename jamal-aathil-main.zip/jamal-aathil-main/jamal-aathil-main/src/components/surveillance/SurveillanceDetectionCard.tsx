import { AlertTriangle, CheckCircle, Clock, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

interface Detection {
  id: string;
  cameraName: string;
  cameraLocation: string;
  detectedAt: Date;
  result: 'matched' | 'unknown' | 'no_face';
  matchedCriminalName?: string;
  matchedCriminalCrime?: string;
  confidence?: number;
  facialFeaturesScore?: number;
  structuralSimilarityScore?: number;
  reasoning?: string;
  frameImageUrl?: string;
  isAlert: boolean;
}

interface SurveillanceDetectionCardProps {
  detection: Detection;
}

export function SurveillanceDetectionCard({ detection }: SurveillanceDetectionCardProps) {
  const isMatch = detection.result === 'matched';

  return (
    <div className={`p-3 rounded-lg border ${
      isMatch 
        ? 'border-destructive/30 bg-destructive/5' 
        : 'border-border bg-muted/30'
    }`}>
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-lg ${
          isMatch ? 'bg-destructive/10' : 'bg-success/10'
        }`}>
          {isMatch ? (
            <AlertTriangle className="w-4 h-4 text-destructive" />
          ) : (
            <CheckCircle className="w-4 h-4 text-success" />
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <p className={`font-medium truncate ${
              isMatch ? 'text-destructive' : 'text-foreground'
            }`}>
              {isMatch ? detection.matchedCriminalName : 'No Match'}
            </p>
            {detection.confidence && (
              <Badge 
                variant={isMatch ? "destructive" : "secondary"}
                className="shrink-0"
              >
                {detection.confidence.toFixed(0)}%
              </Badge>
            )}
          </div>
          
          {isMatch && detection.matchedCriminalCrime && (
            <p className="text-sm text-destructive/80">{detection.matchedCriminalCrime}</p>
          )}
          
          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {format(detection.detectedAt, 'HH:mm:ss')}
            </span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {detection.cameraLocation}
            </span>
          </div>
          
          {detection.reasoning && (
            <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
              {detection.reasoning}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
