import { useEffect, useRef } from 'react';

interface VideoFrameExtractorProps {
  video: HTMLVideoElement;
  isProcessing: boolean;
  frameInterval: number; // in milliseconds
  onFrameExtracted: (frameBase64: string, frameNumber: number) => void;
  onComplete: () => void;
}

export function VideoFrameExtractor({
  video,
  isProcessing,
  frameInterval,
  onFrameExtracted,
  onComplete,
}: VideoFrameExtractorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameCountRef = useRef(0);
  const lastProcessedTimeRef = useRef(0);
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    if (!isProcessing || !video || !canvasRef.current) {
      return;
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    // Reset video to start
    video.currentTime = 0;
    frameCountRef.current = 0;
    lastProcessedTimeRef.current = 0;

    const extractFrame = () => {
      if (!isProcessing) {
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
        return;
      }

      // Check if video has ended
      if (video.ended || video.currentTime >= video.duration) {
        onComplete();
        return;
      }

      const currentTime = video.currentTime * 1000; // Convert to milliseconds
      
      // Check if enough time has passed since last frame
      if (currentTime - lastProcessedTimeRef.current >= frameInterval) {
        // Draw current frame to canvas
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Convert to base64
        const frameBase64 = canvas.toDataURL('image/jpeg', 0.8);
        
        // Increment frame count
        frameCountRef.current += 1;
        lastProcessedTimeRef.current = currentTime;
        
        // Send frame for analysis
        onFrameExtracted(frameBase64, frameCountRef.current);
      }

      // Continue processing
      animationFrameRef.current = requestAnimationFrame(extractFrame);
    };

    // Start video playback and frame extraction
    const handleCanPlay = () => {
      video.play();
      extractFrame();
    };

    const handleEnded = () => {
      onComplete();
    };

    video.addEventListener('canplay', handleCanPlay);
    video.addEventListener('ended', handleEnded);

    // If video is already ready, start immediately
    if (video.readyState >= 3) {
      handleCanPlay();
    }

    return () => {
      video.removeEventListener('canplay', handleCanPlay);
      video.removeEventListener('ended', handleEnded);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      video.pause();
    };
  }, [isProcessing, video, frameInterval, onFrameExtracted, onComplete]);

  return (
    <canvas 
      ref={canvasRef} 
      className="hidden" 
      aria-hidden="true"
    />
  );
}
