import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
  variant?: 'default' | 'accent' | 'success' | 'warning';
}

export function StatCard({ title, value, icon: Icon, description, variant = 'default' }: StatCardProps) {
  return (
    <div className={cn(
      'stat-card animate-fade-in',
      variant === 'accent' && 'stat-card-accent',
      variant === 'success' && 'stat-card-success',
      variant === 'warning' && 'stat-card-warning'
    )}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-3xl font-bold mt-2 text-foreground">{value}</p>
          {description && (
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          )}
        </div>
        <div className={cn(
          'p-3 rounded-lg',
          variant === 'default' && 'bg-primary/10 text-primary',
          variant === 'accent' && 'bg-accent/10 text-accent',
          variant === 'success' && 'bg-success/10 text-success',
          variant === 'warning' && 'bg-warning/10 text-warning'
        )}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}
