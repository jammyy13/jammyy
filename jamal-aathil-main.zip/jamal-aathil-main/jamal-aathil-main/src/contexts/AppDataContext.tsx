import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthContext';

export interface Criminal {
  id: string;
  name: string;
  crime: string;
  imageUrl: string;
  addedAt: Date;
}

export interface RecognitionLog {
  id: string;
  date: Date;
  result: 'Matched' | 'Unknown';
  accuracy: number;
  matchedCriminal?: string;
}

interface AppDataContextType {
  criminals: Criminal[];
  logs: RecognitionLog[];
  totalRecognitions: number;
  alerts: number;
  isLoadingCriminals: boolean;
  addCriminal: (criminal: Omit<Criminal, 'id' | 'addedAt'>) => Promise<void>;
  updateCriminal: (id: string, criminal: Partial<Omit<Criminal, 'id' | 'addedAt'>>) => Promise<void>;
  deleteCriminal: (id: string) => Promise<void>;
  addLog: (log: Omit<RecognitionLog, 'id'>) => void;
  refreshCriminals: () => Promise<void>;
}

const AppDataContext = createContext<AppDataContextType | undefined>(undefined);

async function uploadImageToStorage(base64OrUrl: string, userId: string): Promise<string> {
  // If it's already a public URL (not base64), return as-is
  if (base64OrUrl.startsWith('http')) return base64OrUrl;

  // Convert base64 to blob
  const base64Data = base64OrUrl.split(',')[1];
  if (!base64Data) return base64OrUrl;

  const byteCharacters = atob(base64Data);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  const blob = new Blob([byteArray], { type: 'image/jpeg' });

  const fileName = `${userId}/${Date.now()}-${Math.random().toString(36).slice(2)}.jpg`;

  const { data, error } = await supabase.storage
    .from('criminal-photos')
    .upload(fileName, blob, { contentType: 'image/jpeg' });

  if (error) throw error;

  const { data: urlData } = supabase.storage
    .from('criminal-photos')
    .getPublicUrl(data.path);

  return urlData.publicUrl;
}

export function AppDataProvider({ children }: { children: ReactNode }) {
  const { user, isAuthenticated } = useAuth();
  const [criminals, setCriminals] = useState<Criminal[]>([]);
  const [isLoadingCriminals, setIsLoadingCriminals] = useState(false);
  const [logs, setLogs] = useState<RecognitionLog[]>([]);

  const fetchCriminals = useCallback(async () => {
    if (!user) return;
    setIsLoadingCriminals(true);
    try {
      const { data, error } = await supabase
        .from('criminals')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setCriminals(
        (data || []).map((c) => ({
          id: c.id,
          name: c.name,
          crime: c.crime,
          imageUrl: c.image_url,
          addedAt: new Date(c.created_at),
        }))
      );
    } catch (err) {
      console.error('Error fetching criminals:', err);
    } finally {
      setIsLoadingCriminals(false);
    }
  }, [user]);

  useEffect(() => {
    if (isAuthenticated && user) {
      fetchCriminals();
    } else {
      setCriminals([]);
    }
  }, [isAuthenticated, user, fetchCriminals]);

  const addCriminal = async (criminal: Omit<Criminal, 'id' | 'addedAt'>) => {
    if (!user) throw new Error('Not authenticated');

    const imageUrl = await uploadImageToStorage(criminal.imageUrl, user.id);

    const { error } = await supabase.from('criminals').insert({
      name: criminal.name,
      crime: criminal.crime,
      image_url: imageUrl,
      user_id: user.id,
    });

    if (error) throw error;
    await fetchCriminals();
  };

  const updateCriminal = async (id: string, updates: Partial<Omit<Criminal, 'id' | 'addedAt'>>) => {
    if (!user) throw new Error('Not authenticated');

    const updateData: Record<string, unknown> = {};
    if (updates.name) updateData.name = updates.name;
    if (updates.crime) updateData.crime = updates.crime;
    if (updates.imageUrl) {
      updateData.image_url = await uploadImageToStorage(updates.imageUrl, user.id);
    }

    const { error } = await supabase.from('criminals').update(updateData).eq('id', id);
    if (error) throw error;
    await fetchCriminals();
  };

  const deleteCriminal = async (id: string) => {
    const { error } = await supabase.from('criminals').delete().eq('id', id);
    if (error) throw error;
    await fetchCriminals();
  };

  const addLog = (log: Omit<RecognitionLog, 'id'>) => {
    const newLog: RecognitionLog = { ...log, id: Date.now().toString() };
    setLogs((prev) => [newLog, ...prev]);
  };

  const totalRecognitions = logs.length;
  const alerts = logs.filter((log) => log.result === 'Matched').length;

  return (
    <AppDataContext.Provider
      value={{
        criminals,
        logs,
        totalRecognitions,
        alerts,
        isLoadingCriminals,
        addCriminal,
        updateCriminal,
        deleteCriminal,
        addLog,
        refreshCriminals: fetchCriminals,
      }}
    >
      {children}
    </AppDataContext.Provider>
  );
}

export function useAppData() {
  const context = useContext(AppDataContext);
  if (context === undefined) {
    throw new Error('useAppData must be used within an AppDataProvider');
  }
  return context;
}
