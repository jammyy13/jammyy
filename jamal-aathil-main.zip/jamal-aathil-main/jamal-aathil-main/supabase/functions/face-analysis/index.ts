import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

interface Criminal {
  id: string;
  name: string;
  crime: string;
  imageUrl: string;
}

interface AnalysisRequest {
  uploadedImage: string;
  criminals: Criminal[];
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("AI service not configured");
    }

    const { uploadedImage, criminals }: AnalysisRequest = await req.json();

    if (!uploadedImage) {
      return new Response(
        JSON.stringify({ error: "No image provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!criminals || criminals.length === 0) {
      return new Response(
        JSON.stringify({ error: "No criminal database provided for comparison" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Analyzing face against ${criminals.length} criminal records...`);

    const criminalDescriptions = criminals.map((c, i) => 
      `Criminal ${i + 1}: ${c.name} (ID: ${c.id}) - Crime: ${c.crime}`
    ).join('\n');

    const systemPrompt = `You are an advanced facial recognition AI system used by law enforcement. 
Your task is to analyze an uploaded face image and compare it against known criminal records.

IMPORTANT: This is a simulation for demonstration purposes. Analyze the facial features visible in the images and provide your best assessment.

FIRST, determine if there is a valid face in the uploaded image:
- If NO face is detected (e.g., landscape, object, blurry image), return:
  {"status": "no_face", "reasoning": "explanation"}
- If MULTIPLE faces are detected, return:
  {"status": "multiple_faces", "faceCount": number, "reasoning": "explanation"}
- If exactly ONE face is detected, proceed with comparison.

For a single face comparison, consider:
1. Facial structure and bone structure
2. Eye shape, spacing, and characteristics
3. Nose shape and size
4. Mouth and lip characteristics
5. Overall facial proportions
6. Distinguishing marks or features

For a successful single-face analysis, respond with:
{
  "status": "analyzed",
  "matched": boolean,
  "matchedCriminalId": "string or null",
  "matchedCriminalName": "string or null", 
  "accuracy": number between 0 and 100,
  "facialFeaturesScore": number between 0 and 100,
  "structuralSimilarityScore": number between 0 and 100,
  "reasoning": "brief explanation of your analysis"
}

If no match is found with confidence above 70%, set matched to false.
Be realistic - not every face will match a criminal.
Respond ONLY with JSON, no other text.`;

    const content: any[] = [
      {
        type: "text",
        text: `Analyze the uploaded face image and compare it against the following criminal database:\n\n${criminalDescriptions}\n\nI will provide the uploaded image first, followed by the criminal reference images.`
      },
      {
        type: "image_url",
        image_url: { url: uploadedImage }
      },
      {
        type: "text",
        text: "Above is the uploaded image to analyze. Below are the criminal reference images:"
      }
    ];

    for (const criminal of criminals) {
      content.push({
        type: "text",
        text: `Reference image for ${criminal.name} (ID: ${criminal.id}):`
      });
      content.push({
        type: "image_url",
        image_url: { url: criminal.imageUrl }
      });
    }

    content.push({
      type: "text",
      text: "Now provide your facial comparison analysis in the specified JSON format."
    });

    console.log("Sending request to Lovable AI for facial analysis...");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content }
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`AI gateway error: ${response.status}`, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      throw new Error(`AI analysis failed: ${response.status}`);
    }

    const aiResponse = await response.json();
    const aiContent = aiResponse.choices?.[0]?.message?.content;

    if (!aiContent) {
      throw new Error("AI returned empty response");
    }

    console.log("AI response received:", aiContent);

    let analysisResult;
    try {
      const jsonMatch = aiContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisResult = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in response");
      }
    } catch (parseError) {
      console.error("Failed to parse AI response:", parseError);
      analysisResult = {
        status: "analyzed",
        matched: false,
        matchedCriminalId: null,
        matchedCriminalName: null,
        accuracy: 45,
        facialFeaturesScore: 42,
        structuralSimilarityScore: 48,
        reasoning: "Unable to process facial analysis. The uploaded image may not contain a clear face."
      };
    }

    // Handle no_face and multiple_faces status
    if (analysisResult.status === "no_face") {
      return new Response(
        JSON.stringify({
          status: "no_face",
          matched: false,
          accuracy: 0,
          reasoning: analysisResult.reasoning || "No face detected in the uploaded image.",
          analysisDetails: { facialFeaturesScore: 0, structuralSimilarityScore: 0, overallConfidence: 0 },
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (analysisResult.status === "multiple_faces") {
      return new Response(
        JSON.stringify({
          status: "multiple_faces",
          matched: false,
          accuracy: 0,
          faceCount: analysisResult.faceCount || 2,
          reasoning: analysisResult.reasoning || "Multiple faces detected. Please upload an image with a single face.",
          analysisDetails: { facialFeaturesScore: 0, structuralSimilarityScore: 0, overallConfidence: 0 },
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Find matched criminal
    let matchedCriminal: Criminal | undefined;
    if (analysisResult.matched && analysisResult.matchedCriminalId) {
      matchedCriminal = criminals.find(c => c.id === analysisResult.matchedCriminalId);
      if (!matchedCriminal && analysisResult.matchedCriminalName) {
        matchedCriminal = criminals.find(c => 
          c.name.toLowerCase().includes(analysisResult.matchedCriminalName.toLowerCase()) ||
          analysisResult.matchedCriminalName.toLowerCase().includes(c.name.toLowerCase())
        );
      }
    }

    const result = {
      status: "analyzed",
      matched: analysisResult.matched && matchedCriminal !== undefined,
      accuracy: analysisResult.accuracy || 0,
      matchedCriminal: matchedCriminal || null,
      analysisDetails: {
        facialFeaturesScore: analysisResult.facialFeaturesScore || analysisResult.accuracy,
        structuralSimilarityScore: analysisResult.structuralSimilarityScore || analysisResult.accuracy,
        overallConfidence: analysisResult.accuracy || 0,
      },
      reasoning: analysisResult.reasoning || "Analysis complete."
    };

    console.log("Analysis complete:", JSON.stringify(result, null, 2));

    return new Response(
      JSON.stringify(result),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Face analysis error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
