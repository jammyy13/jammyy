
-- Create criminals table for persistent storage
CREATE TABLE public.criminals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  crime TEXT NOT NULL,
  image_url TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.criminals ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own criminals"
ON public.criminals
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own criminals"
ON public.criminals
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own criminals"
ON public.criminals
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own criminals"
ON public.criminals
FOR DELETE
USING (auth.uid() = user_id);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_criminals_updated_at
BEFORE UPDATE ON public.criminals
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add index for faster lookups
CREATE INDEX idx_criminals_user_id ON public.criminals(user_id);
