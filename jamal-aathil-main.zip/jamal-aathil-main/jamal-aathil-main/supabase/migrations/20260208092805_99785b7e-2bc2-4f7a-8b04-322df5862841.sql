
-- Create storage bucket for criminal photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('criminal-photos', 'criminal-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload criminal photos
CREATE POLICY "Authenticated users can upload criminal photos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'criminal-photos');

-- Allow public read access to criminal photos
CREATE POLICY "Anyone can view criminal photos"
ON storage.objects FOR SELECT
USING (bucket_id = 'criminal-photos');

-- Allow authenticated users to update their own criminal photos
CREATE POLICY "Authenticated users can update criminal photos"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'criminal-photos');

-- Allow authenticated users to delete criminal photos
CREATE POLICY "Authenticated users can delete criminal photos"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'criminal-photos');
