-- Create table for CCTV cameras/locations
CREATE TABLE public.cctv_cameras (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  location TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'maintenance')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for surveillance detection logs
CREATE TABLE public.surveillance_detections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  camera_id UUID REFERENCES public.cctv_cameras(id) ON DELETE SET NULL,
  camera_name TEXT,
  camera_location TEXT,
  detected_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  result TEXT NOT NULL CHECK (result IN ('matched', 'unknown', 'no_face')),
  matched_criminal_name TEXT,
  matched_criminal_id TEXT,
  matched_criminal_crime TEXT,
  confidence NUMERIC(5,2),
  facial_features_score NUMERIC(5,2),
  structural_similarity_score NUMERIC(5,2),
  reasoning TEXT,
  frame_image_url TEXT,
  is_alert BOOLEAN NOT NULL DEFAULT false,
  alert_acknowledged BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.cctv_cameras ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.surveillance_detections ENABLE ROW LEVEL SECURITY;

-- RLS policies for cctv_cameras
CREATE POLICY "Users can view their own cameras"
ON public.cctv_cameras
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own cameras"
ON public.cctv_cameras
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own cameras"
ON public.cctv_cameras
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own cameras"
ON public.cctv_cameras
FOR DELETE
USING (auth.uid() = user_id);

-- RLS policies for surveillance_detections
CREATE POLICY "Users can view their own detections"
ON public.surveillance_detections
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own detections"
ON public.surveillance_detections
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own detections"
ON public.surveillance_detections
FOR UPDATE
USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX idx_surveillance_detections_user_id ON public.surveillance_detections(user_id);
CREATE INDEX idx_surveillance_detections_detected_at ON public.surveillance_detections(detected_at DESC);
CREATE INDEX idx_surveillance_detections_is_alert ON public.surveillance_detections(is_alert);
CREATE INDEX idx_cctv_cameras_user_id ON public.cctv_cameras(user_id);

-- Add trigger for updated_at on cctv_cameras
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_cctv_cameras_updated_at
BEFORE UPDATE ON public.cctv_cameras
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();